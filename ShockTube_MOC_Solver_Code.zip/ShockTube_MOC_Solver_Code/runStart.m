addpath(genpath(pwd))
SetDefaultFigureProp('Times New Roman',25)